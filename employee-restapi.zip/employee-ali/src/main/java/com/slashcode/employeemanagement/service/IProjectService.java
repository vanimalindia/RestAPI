package com.slashcode.employeemanagement.service;

import java.util.List;

import com.slashcode.employeemanagement.dto.*;

public interface IProjectService {

	List<Project> getProjectList(int empId);

	Project getProjectById(int id);

	void addProject(Project proj);

	void updateProject(Project proj);

	void deleteProjectById(int id);

	List<Project> getAllProject();
}
