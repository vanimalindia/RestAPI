package com.slashcode.employeemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementAPI {
	public static void main(String[] args)
	{
		SpringApplication.run(EmployeeManagementAPI.class, args);
	}

}
