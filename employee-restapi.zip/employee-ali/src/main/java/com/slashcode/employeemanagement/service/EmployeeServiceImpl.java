package com.slashcode.employeemanagement.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slashcode.employeemanagement.dao.IEmployeeDao;
import com.slashcode.employeemanagement.dto.Employee;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	List<Employee> empList = new ArrayList<> (Arrays.asList(                        // This is Arrays.asList() un-mutable
			new Employee(1,"Er.Shakir Syyed","IT Department"),                       // Now we made it mutable List<Employee> empList = new ArrayList<> (Arrays.asList)
			new Employee(2,"Feeda Hussain","HR Department"),
			new Employee(3,"Zoya Khan","Medical Science"),
			new Employee(4,"Zara Hayat Khan","Finance Report"),
			new Employee(5,"Insha Sayyed","Media Professional")));
	
	@Autowired
	private IEmployeeDao daoRef;

	@Override
	public List<Employee> getAllEmployee() {
		//return empList;
		return daoRef.findAll();
	}

	@Override
	public Employee getEmployeeById(int empId) {
		//return empList.stream().filter(e->e.getEmpId() == empId).findFirst().get();
		return daoRef.getOne(empId);
	}

	@Override
	public void addEmployee(Employee employee) {
		//empList.add(employee);
		daoRef.save(employee);
		
	}

	@Override
	public void updateEmployee(Employee employee, int empId) {
		/*for(int i=0; i<empList.size(); i++) {
			Employee e = empList.get(i);
			if(e.getEmpId()==empId) {
				empList.set(i, employee);
				return;
			}
		}*/
		daoRef.save(employee);
	}

	@Override
	public void deleteEmployee(int empId) {
		//empList.removeIf(e -> e.getEmpId()==empId);
		daoRef.deleteById(empId);
	}

	@Override
	public List<Employee> getEmployeeByDept(String deptName) {
		return daoRef.findByDeptName(deptName);
	}

}
